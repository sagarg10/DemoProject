﻿using CodisAssesment.Entities;
using CodisAssesment.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace CodisAssesment.DataLayer.DataSources.Xml
{
    public class XmlAddressDataSourcesDL : IAddressDataSources
    {
        public void AddAddress(Guid personId, Address address)
        {
            throw new NotImplementedException();
        }

        public void DeleteAddress(Guid personId, Guid? addressId)
        {
            throw new NotImplementedException();
        }

        public List<Address> GetAllAddressByPersonId(Guid personId)
        {
            throw new NotImplementedException();
        }

        public void UpdateAddress(Guid personId, Address address)
        {
            throw new NotImplementedException();
        }
    }
}
