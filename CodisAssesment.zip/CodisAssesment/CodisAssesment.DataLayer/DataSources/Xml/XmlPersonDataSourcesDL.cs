﻿using CodisAssesment.Entities;
using CodisAssesment.Entities.Interfaces;
using System;
using System.Collections.Generic;

namespace CodisAssesment.DataLayer.DataSources
{
    public class XmlPersonDataSourcesDL : IPersonDataSources
    {
        public void AddPerson(Person person)
        {
            throw new NotImplementedException();
        }

        public void DeletePerson(Guid? personId)
        {
            throw new NotImplementedException();
        }

        public List<Person> GetAllPerson()
        {
            throw new NotImplementedException();
        }

        public void SaveAllPerson(List<Person> personList)
        {
            throw new NotImplementedException();
        }

        public void UpdatePerson(Person person)
        {
            throw new NotImplementedException();
        }
    }
}
