﻿using CodisAssesment.Entities;
using CodisAssesment.Entities.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CodisAssesment.DataLayer.DataSources.Json
{
    public class JsonAddressDataSourcesDL : IAddressDataSources
    {
       private readonly JsonPersonDataSourcesDL _jsonPersonDataSourcesDL;

       public JsonAddressDataSourcesDL()
        {
            _jsonPersonDataSourcesDL = new JsonPersonDataSourcesDL();
        }
        public List<Address> GetAllAddressByPersonId(Guid personId)
        {
            List<Address> addressList = new List<Address>();
            List<Person> personList = new List<Person>();
            try
            {
                personList=_jsonPersonDataSourcesDL.GetAllPerson();
                 addressList = personList.FirstOrDefault(i => i.PersonId == personId)?.Address;

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
            return addressList;
        }

        public void AddAddress(Guid personId, Address address)
        {
            List<Person> personList = new List<Person>();
            try
            {
                personList = _jsonPersonDataSourcesDL.GetAllPerson();
                var personData = personList.FirstOrDefault(i => i.PersonId == personId);
                personData?.Address.Add(address);
                _jsonPersonDataSourcesDL.SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void DeleteAddress(Guid personId, Guid? addressId)
        {
            List<Person> personList = new List<Person>();
            try
            {
                personList = _jsonPersonDataSourcesDL.GetAllPerson();
                var personData = personList.FirstOrDefault(i => i.PersonId == personId);
                personData?.Address.Remove(personData?.Address.FirstOrDefault(i=>i.addressId==addressId));
                _jsonPersonDataSourcesDL.SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void UpdateAddress(Guid personId, Address address)
        {
            List<Person> personList = new List<Person>();
            try
            {
                DeleteAddress(personId, address.addressId);
                personList = _jsonPersonDataSourcesDL.GetAllPerson();
                var personData = personList.FirstOrDefault(i => i.PersonId == personId);
                personData?.Address.Add(address);
                _jsonPersonDataSourcesDL.SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }
    }
}
