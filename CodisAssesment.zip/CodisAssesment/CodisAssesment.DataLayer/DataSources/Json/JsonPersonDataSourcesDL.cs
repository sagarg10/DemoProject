﻿using CodisAssesment.Entities;
using CodisAssesment.Entities.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CodisAssesment.DataLayer.DataSources
{
    public class JsonPersonDataSourcesDL : IPersonDataSources
    {

        public List<Person> GetAllPerson()
        {
            List<Person> personList = new List<Person>();
            try
            {

                string jsonString = File.ReadAllText(Constants.JsonDataSourceFile);

                if(!string.IsNullOrEmpty(jsonString))
                personList = JsonConvert.DeserializeObject<List<Person>>(jsonString);
     
            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
            return personList;
        }

        public void SaveAllPerson(List<Person> personList)
        {
            try
            {
                if(personList?.Count>0)
                {
                   string newJsonResult = JsonConvert.SerializeObject(personList, Formatting.Indented);
                    File.WriteAllText(Constants.JsonDataSourceFile, newJsonResult);
                }
               
            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void UpdatePerson(Person person)
        {
            try
            {

                DeletePerson(person.PersonId);
                AddPerson(person);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void AddPerson(Person person)
        {
            List<Person> personList = new List<Person>();
            try
            {

                personList = GetAllPerson();
                personList.Add(person);
                SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }

        }

        public void DeletePerson(Guid? personId)
        {
            List<Person> personList = new List<Person>();
            try
            {

                personList = GetAllPerson();
                personList.Remove(personList.FirstOrDefault(s => s.PersonId == personId));
                SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }

        }
    }
}
