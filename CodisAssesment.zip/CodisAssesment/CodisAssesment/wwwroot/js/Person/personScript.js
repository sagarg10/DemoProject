﻿
$(document).ready(function () {

    let editFlag = false;
    let editPersonObj = new Object();
    let personDt = $("#personDataTable").DataTable({
        "processing": true, // for show progress bar
        "serverSide": true, // for process server side
        "filter": true, // this is for disable filter (search box)
        "orderMulti": false, // for disable multiple column at once
        "ajax": {
            "url": "/Person/LoadData",
            "type": "POST",
            "datatype": "json"
        },
        "columnDefs":
            [{
                "targets": [0],
                "visible": false,
                "searchable": false
            }],
        "columns": [
            { "data": "personId", "name": "personId", "autoWidth": true },
            { "data": "firstName", "name": "firstName", "autoWidth": true },
            { "data": "lastName", "name": "lastName", "autoWidth": true },
            { "data": "dateOfBirth", "name": "dateOfBirth", "autoWidth": true },
            { "data": "nickName", "name": "nickName", "autoWidth": true },
            {
                "render": function (data, type, full, meta) {
                    return '<a class="btn btn-Warning" href="/Address/ShowGrid?personId=' + full.personId + '">Add/Edit</a>';
                }
            },
            {
                data: null, render: function (data, type, row) {
                    debugger
                    return "<a href='#' class='btn btn-info' onclick=editPersonData('" + row.personId + "'); >Edit</a>";
                }
            },
            {
                data: null, render: function (data, type, row) {
                    return "<a href='#' class='btn btn-danger' onclick=deletePersonData('" + row.personId + "'); >Delete</a>";
                }
            },
        ]

    });


    $("#personForm").validate({
        rules: {
            //This section we need to place our custom rule for the control.
            'first-name': {
                required: true, checkName: true
            },
            'last-name': {
                required: true, checkName: true
            },
            'date-of-birth': {
                required: true
            }

        },
        messages: {
            //This section we need to place our custom validation message for each control.
            'first-name': {
                required: 'Please provide your First Name', checkName: 'Person with the same First Name and Last Name already exits.'
            },
            'last-name': {
                required: 'Please provide your Last Name', checkName: 'Person with the same First Name and Last Name already exits.'
            },
            'date-of-birth': {
                required: 'Please provide your Date Of Birth'
            }
        },
    });

});


function deletePersonData(personId) {
    if (confirm("Are you sure you want to delete ...?")) {
        debugger
        let url = '/Person/Delete?personId=' + personId;
        $.ajax(
            {
                url: url,
                type: 'POST',
                processData: false,
                // contentType: "application/json; charset=utf-8",
                // data: JSON.stringify({ personId: personId}),
                complete: function () {
                    dtReloadAndModelClose();
                },
                error: function () {
                    dtReloadAndModelClose();
                }
            });
    }
    else {
        return false;
    }
};

function editPersonData(personId) {
    debugger
    editFlag = true;
    editPersonId = personId;
    const table = $('#personDataTable').DataTable();
    const allRowData = table.rows().data();
    $("#personModalLabel").text("Edit  person.");


    for (let i = 0; i < allRowData.length; i++) {
        if (allRowData[i].personId == personId) {
            editPersonObj = allRowData[i];
            $("#first-name").val(allRowData[i].firstName);
            $("#last-name").val(allRowData[i].lastName);
            $("#nick-name").val(allRowData[i].nickName);
            $("#date-of-birth").val(allRowData[i].dateOfBirth);
            break;
        }
    }

    $('#personModal').modal('show');
};




$("#personModalBtn").click(function (e) {
    e.preventDefault();
    $("#personModalLabel").text("Add new person.");
    $('#personModal').modal('show');

});

$('#personModal').on('hidden.bs.modal', function () {
    $(this).find('form').trigger('reset');
})


$("#savePerson").click(function (e) {
    e.preventDefault();

    if ($("#personForm").valid()) {

        person = new Object();
        person.firstName = $("#first-name").val().trim();
        person.lastName = $("#last-name").val().trim();
        person.nickName = $("#nick-name").val();
        person.dateOfBirth = $("#date-of-birth").val();

        let url = '';
        if (editFlag) {
            url = '/Person/Edit';
            person.PersonId = editPersonId;
            person.Address = editPersonObj.Address;
        }
        else {
            url = '/Person/Add';
            person.PersonId = null;
            person.Address = [];
        }

        $.ajax(
            {
                url: url,
                type: 'POST',
                processData: false,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(person),
                complete: function () {
                    dtReloadAndModelClose();
                },
                error: function () {
                    dtReloadAndModelClose();
                }
            });
    }

});

function dtReloadAndModelClose() {
    $('#personModal').modal('hide');
    $("#personDataTable").DataTable().ajax.reload();
}


function restrictNumbers(event) {
    return !(event.key == '1' || event.key == '2' || event.key == '3' || event.key == '4' || event.key == '5' || event.key == '6' || event.key == '7' || event.key == '8' || event.key == '9' || event.key == '0');
};

jQuery.validator.methods.checkName = function (value, element, params) {
    const table = $('#personDataTable').DataTable();
    const allRowData = table.rows().data();

    return validatePersonName(allRowData);
};

function validatePersonName(allRowData) {

    const firstName = $("#first-name").val().trim().toLowerCase();
    const lastName = $("#last-name").val().trim().toLowerCase();
    let flag = true;
    debugger
    if (allRowData != null) {

        for (let i = 0; i < allRowData.length; i++) {
            if (editFlag) {
                if (editPersonObj.personId != allRowData[i].personId && allRowData[i].firstName.trim().toLowerCase() === firstName && allRowData[i].lastName.trim().toLowerCase() === lastName) {
                    debugger
                    flag = false;
                    break;
                }
            } else {
                if (allRowData[i].firstName.trim().toLowerCase() === firstName && allRowData[i].lastName.trim().toLowerCase() === lastName) {
                    flag = false;
                    break;
                }
            }

        }
    }

    return flag;
}