﻿
let editFlag = false;
let editAddressObj = new Object();
const personId = $("#personId").val();

$(document).ready(function () {


    let AddressDt = $("#AddressDataTable").DataTable({
        "processing": true, // for show progress bar
        "serverSide": true, // for process server side
        "filter": true, // this is for disable filter (search box)
        "orderMulti": false, // for disable multiple column at once
        "ajax": {
            "url": "/Address/LoadData?personId=" + personId,
            "type": "POST",
            "datatype": "json"
        },
        "columnDefs":
            [{
                "targets": [0],
                "visible": false,
                "searchable": false
            }],
        "columns": [
            { "data": "addressId", "name": "addressId", "autoWidth": true },
            { "data": "addressLine1", "name": "addressLine1", "autoWidth": true },
            { "data": "addressLine2", "name": "addressLine2", "autoWidth": true },
            { "data": "country", "name": "country", "autoWidth": true },
            { "data": "postcode", "name": "postcode", "autoWidth": true },
            {
                data: null, render: function (data, type, row) {
                    debugger
                    return "<a href='#' class='btn btn-info' onclick=editAddressData('" + row.addressId + "'); >Edit</a>";
                }
            },
            {
                data: null, render: function (data, type, row) {
                    return "<a href='#' class='btn btn-danger' onclick=deleteAddressData('" + row.addressId + "'); >Delete</a>";
                }
            },
        ],
        "dom": 'lrtip'

    });

    $("#addressForm").validate({
        rules: {
            //This section we need to place our custom rule for the control.
            'line1': {
                required: true, checkAddress: true
            },
            'line2': {
                checkAddress: true
            },
            'postcode': {
                checkAddress: true
            }

        },
        messages: {
            //This section we need to place our custom validation message for each control.
            'line1': {
                required: 'Please provide your Address Line 1', checkAddress: 'Address already exists.'
            },
            'line2': {
                checkAddress: 'Address already exists.'
            },
            'postcode': {
                checkAddress: 'Address already exists.'
            }
        },
    });


    $("#saveAddress").click(function (e) {
        e.preventDefault();

        if ($("#addressForm").valid()) {

            let address = new Object();
            address.addressLine1 = $("#line1").val();
            address.addressLine2 = $("#line2").val();
            address.postcode = $("#postcode").val();
            address.country = $("#country option:selected").val();


            debugger
            let url = '';
            if (editFlag) {
                url = '/Address/Edit?personId=' + personId;
                address.addressId = editAddressObj.addressId;
            }
            else {
                url = '/Address/Add?personId=' + personId;
                address.addressId = null;
            }

            $.ajax(
                {
                    url: url,
                    type: 'POST',
                    //processData: false,
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(address),
                    complete: function () {
                        dtReloadAndModelClose();
                    },
                    error: function () {
                        dtReloadAndModelClose();
                    }
                });
        }

    });

});


function deleteAddressData(addressId) {
    if (confirm("Are you sure you want to delete ...?")) {
        debugger
        let url = '/Address/Delete?personId=' + personId + '&addressId=' + addressId;
        $.ajax(
            {
                url: url,
                type: 'POST',
                processData: false,
                // contentType: "application/json; charset=utf-8",
                // data: JSON.stringify({ addressId: addressId}),
                complete: function () {
                    dtReloadAndModelClose();
                },
                error: function () {
                    dtReloadAndModelClose();
                }
            });
    }
    else {
        return false;
    }
};

function editAddressData(addressId) {
    debugger
    editFlag = true;
    const table = $('#AddressDataTable').DataTable();
    const allRowData = table.rows().data();
    $("#addressModalLabel").text("Edit  Address.");

    for (let i = 0; i < allRowData.length; i++) {
        if (allRowData[i].addressId == addressId) {
            editAddressObj = allRowData[i];
            $("#line1").val(allRowData[i].addressLine1);
            $("#line2").val(allRowData[i].addressLine2);
            $("#postcode").val(allRowData[i].postcode);
            $("#country").val(allRowData[i].country);
            break;
        }
    }

    $('#addressModal').modal('show');
};


$("#addressModalBtn").click(function (e) {
    e.preventDefault();
    $("#addressModalLabel").text("Add new Address.");
    $('#addressModal').modal('show');

});

$('#addressModal').on('hidden.bs.modal', function () {
    $(this).find('form').trigger('reset');
})



function dtReloadAndModelClose() {
    $('#addressModal').modal('hide');
    $("#AddressDataTable").DataTable().ajax.reload();
}


function restrictNumbers(event) {
    return !(event.key == '1' || event.key == '2' || event.key == '3' || event.key == '4' || event.key == '5' || event.key == '6' || event.key == '7' || event.key == '8' || event.key == '9' || event.key == '0');
};

function onlyNumbers(event) {
    return (event.key == '1' || event.key == '2' || event.key == '3' || event.key == '4' || event.key == '5' || event.key == '6' || event.key == '7' || event.key == '8' || event.key == '9' || event.key == '0');
};

jQuery.validator.methods.checkAddress = function (value, element, params) {
    const table = $('#AddressDataTable').DataTable();
    const allRowData = table.rows().data();

    return validateAddressName(allRowData);
};

function validateAddressName(allRowData) {

    let line1 = $("#line1").val().trim();
    let line2 = $("#line2").val();
    let postcode = $("#postcode").val();
    let country = $("#country option:selected").val();
    let flag = true;
    debugger
    if (allRowData != null) {

        for (let i = 0; i < allRowData.length; i++) {
            if (editFlag) {
                if (editAddressObj.addressId != allRowData[i].addressId && allRowData[i].addressLine1.trim() == line1 && allRowData[i].addressLine2 == line2 && allRowData[i].country == country & allRowData[i].postcode == postcode  ) {
                    debugger
                    flag = false;
                    break;
                }
            } else {
                if (allRowData[i].addressLine1.trim() == line1 && allRowData[i].addressLine2 == line2 && allRowData[i].country == country & allRowData[i].postcode == postcode ) {
                    flag = false;
                    break;
                }
            }

        }
    }

    return flag;
}