﻿using System;
using System.Collections.Generic;
using System.Linq;
using CodisAssesment.BusinessLayer;
using CodisAssesment.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CodisAssesment.Controllers
{
    public class PersonController : Controller
    {
        private readonly PersonDetailsBL _personDetailsBL;
        public PersonController()
        {
            _personDetailsBL = new PersonDetailsBL();
        }

        public IActionResult Index()
        {
            return View("ShowGrid");
        }

        public IActionResult LoadData()
        {
            try
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
                // Skiping number of Rows count
                var start = Request.Form["start"].FirstOrDefault();
                // Paging Length 10,20
                var length = Request.Form["length"].FirstOrDefault();
                // Sort Column Name
                var sortColumn = Request.Form["columns[" + Request.Form["order[1][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                // Sort Column Direction ( asc ,desc)
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
                // Search Value from (Search box)
                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                //Paging Size (10,20,50,100)
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all person data
                List<Person> personData = _personDetailsBL.GetAllPerson(Constants.DataTypes.Json);

                //Sorting
                if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDirection)))
                {
                    // Implement Order By
                }
                //Search
                if (!string.IsNullOrEmpty(searchValue))
                {
                    personData = personData.Where(m => m.firstName.ToLower().Contains(searchValue.ToLower()) || m.lastName.ToLower().Contains(searchValue.ToLower()))?.ToList();
                }

                //total number of rows count 
                recordsTotal = personData.Count();
                //Paging 
                var data = personData.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data
                return Json(new { draw, recordsFiltered = recordsTotal, recordsTotal, data });

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }

        }

        [HttpPost]
        public void Edit([FromBody]Person person)
        {
            try
            {
                _personDetailsBL.UpdatePerson(person, Constants.DataTypes.Json);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        [HttpPost]
        public void Delete(Guid personId)
        {
            try
            {
                _personDetailsBL.DeletePerson(personId, Constants.DataTypes.Json);
            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        [HttpPost]
        public void Add([FromBody]Person person)
        {
            try
            {
                person.PersonId = Guid.NewGuid();
                _personDetailsBL.AddPerson(person, Constants.DataTypes.Json);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }
    }
}
