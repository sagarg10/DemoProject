﻿using System;
using System.Collections.Generic;
using System.Linq;
using CodisAssesment.BusinessLayer;
using CodisAssesment.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CodisAssesment.Web.Controllers
{
    public class AddressController : Controller
    {
        private readonly AddressDetailsBL _addressDetailsBL;
        public AddressController()
        {
            _addressDetailsBL = new AddressDetailsBL();
        }

        public IActionResult ShowGrid(Guid personId)
        {
            ViewBag.personId = personId;
            return View("ShowGrid");
        }

        public IActionResult LoadData(Guid personId)
        {
            try
            {
                var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
                // Skiping number of Rows count
                var start = Request.Form["start"].FirstOrDefault();
                // Paging Length 10,20
                var length = Request.Form["length"].FirstOrDefault();
                // Sort Column Name
                var sortColumn = Request.Form["columns[" + Request.Form["order[1][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                // Sort Column Direction ( asc ,desc)
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
                // Search Value from (Search box)
                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                //Paging Size (10,20,50,100)
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all person data
                List<Address> addressData = _addressDetailsBL.GetAllAddressByPersonId(personId, Constants.DataTypes.Json);

                //Sorting
                if (!(string.IsNullOrEmpty(sortColumn) && string.IsNullOrEmpty(sortColumnDirection)))
                {
                    // Implement Order By
                }
                //Search
                if (!string.IsNullOrEmpty(searchValue))
                {
                    // Implement Search
                }

                //total number of rows count 
                recordsTotal = addressData.Count();
                //Paging 
                var data = addressData.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data
                return Json(new { draw, recordsFiltered = recordsTotal, recordsTotal, data });

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }

        }

        [HttpPost]
        public void Edit(Guid personId,[FromBody] Address address)
        {
            try
            {
                _addressDetailsBL.UpdateAddress(personId, address, Constants.DataTypes.Json);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        [HttpPost]
        public void Delete(Guid personId,Guid addressId)
        {
            try
            {
                _addressDetailsBL.DeleteAddress(personId, addressId, Constants.DataTypes.Json);
            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        [HttpPost]
        public void Add(Guid personId,[FromBody]Address address)
        {
            try
            {
                if (address != null)
                    address.addressId = Guid.NewGuid();
                _addressDetailsBL.AddAddress(personId, address, Constants.DataTypes.Json);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }
    }
}