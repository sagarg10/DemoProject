﻿using System;
using System.Collections.Generic;

namespace CodisAssesment.Entities.Interfaces
{
   public interface IPersonDataSources
    {
        List<Person> GetAllPerson();

       void SaveAllPerson(List<Person> personList);
        void AddPerson(Person person);

        void DeletePerson(Guid? personId);

        void UpdatePerson(Person person);
    }
}
