﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodisAssesment.Entities.Interfaces
{
    public interface IAddressDataSources
    {
        List<Address> GetAllAddressByPersonId(Guid personId);

         void AddAddress(Guid personId, Address address);
        void UpdateAddress(Guid personId, Address address);

        void DeleteAddress(Guid personId, Guid? addressId);
    }
}
