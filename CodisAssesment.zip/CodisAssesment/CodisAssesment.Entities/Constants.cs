﻿namespace CodisAssesment.Entities
{
    public static class Constants
    {
        public enum DataTypes
        {
            Json,
            Xml
        }

        public static string JsonDataSourceFile = @"C:\Users\sagar Gupta\source\repos\CodisAssesment\CodisAssesment.DataLayer\SourceFiles\Json\personData.json";
    }
}
