﻿using System;
using System.Collections.Generic;

namespace CodisAssesment.Entities
{
    public class Person
    {
        public Person()
        {
            Address = new List<Address>();
        }
        public Guid? PersonId { get; set; }

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string dateOfBirth { get; set; }
        public string nickName { get; set; }

        public List<Address> Address { get; set; }

    }
}
