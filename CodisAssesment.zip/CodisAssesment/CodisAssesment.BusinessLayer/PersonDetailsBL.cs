﻿using CodisAssesment.BusinessLayer.Factory;
using CodisAssesment.Entities;
using System;
using System.Collections.Generic;

namespace CodisAssesment.BusinessLayer
{
    public class PersonDetailsBL
    {

       private readonly DataSourcesFactory _dataSourcesFactory;
        public PersonDetailsBL()
        {
             _dataSourcesFactory = new DataSourcesFactory();
        }

        public List<Person> GetAllPerson(Constants.DataTypes dataTypes)
        {
            List<Person> personList = new List<Person>();
            try
            {
                personList = _dataSourcesFactory.GetPersonDataSources(dataTypes).GetAllPerson();

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
            return personList;

        }

        public void SaveAllPerson(List<Person> personList, Constants.DataTypes dataTypes)
        {
            try
            {
                 _dataSourcesFactory.GetPersonDataSources(dataTypes).SaveAllPerson(personList);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void AddPerson(Person person, Constants.DataTypes dataTypes)
        {
            try
            {
                _dataSourcesFactory.GetPersonDataSources(dataTypes).AddPerson(person);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void UpdatePerson(Person person, Constants.DataTypes dataTypes)
        {
            try
            {
                _dataSourcesFactory.GetPersonDataSources(dataTypes).UpdatePerson(person);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void DeletePerson(Guid personId, Constants.DataTypes dataTypes)
        {
            try
            {
                _dataSourcesFactory.GetPersonDataSources(dataTypes).DeletePerson(personId);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }
    }
}
