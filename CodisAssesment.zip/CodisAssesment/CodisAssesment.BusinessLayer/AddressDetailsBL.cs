﻿using CodisAssesment.BusinessLayer.Factory;
using CodisAssesment.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CodisAssesment.BusinessLayer
{
   public class AddressDetailsBL
    {

        private readonly DataSourcesFactory _dataSourcesFactory;
        public AddressDetailsBL()
        {
            _dataSourcesFactory = new DataSourcesFactory();
        }

        public List<Address> GetAllAddressByPersonId(Guid personId,Constants.DataTypes dataTypes)
        {
            List<Address> addressList = new List<Address>();
            try
            {
                addressList = _dataSourcesFactory.GetAddressDataSources(dataTypes).GetAllAddressByPersonId(personId);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
            return addressList;

        }

        public void AddAddress(Guid personId, Address address, Constants.DataTypes dataTypes)
        {
            List<Person> personList = new List<Person>();
            try
            {
                _dataSourcesFactory.GetAddressDataSources(dataTypes).AddAddress(personId, address);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void UpdateAddress(Guid personId, Address address, Constants.DataTypes dataTypes)
        {
            List<Person> personList = new List<Person>();
            try
            {
                _dataSourcesFactory.GetAddressDataSources(dataTypes).UpdateAddress(personId, address);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }

        public void DeleteAddress(Guid personId, Guid addressId, Constants.DataTypes dataTypes)
        {
            try
            {
                _dataSourcesFactory.GetAddressDataSources(dataTypes).DeleteAddress(personId, addressId);

            }
            catch (Exception ex)
            {
                throw ex;
                //Implementation required
            }
        }
    }
}
