﻿using CodisAssesment.DataLayer.DataSources;
using CodisAssesment.DataLayer.DataSources.Json;
using CodisAssesment.DataLayer.DataSources.Xml;
using CodisAssesment.Entities;
using CodisAssesment.Entities.Interfaces;

namespace CodisAssesment.BusinessLayer.Factory
{
    public class DataSourcesFactory
    {
        public  IAddressDataSources GetAddressDataSources(Constants.DataTypes dataType)
        {
            switch (dataType)
            {
                case Constants.DataTypes.Json:
                    return new JsonAddressDataSourcesDL();
                case Constants.DataTypes.Xml:
                    return new XmlAddressDataSourcesDL();
                default:
                    return new JsonAddressDataSourcesDL();

            }
        }

        public IPersonDataSources GetPersonDataSources(Constants.DataTypes dataType)
        {
            switch (dataType)
            {
                case Constants.DataTypes.Json:
                    return new JsonPersonDataSourcesDL();
                case Constants.DataTypes.Xml:
                    return new XmlPersonDataSourcesDL();
                default:
                    return new JsonPersonDataSourcesDL();

            }
        }


    }
}
